
(function(compId){"use strict";var _=null,y=true,n=false,x2='5.0.0.375',e63='${Block_store}',x32='149px',e16='${Click2}',x12='800',x43='Block_store',e66='${Store_like}',x37='sound_wave',b='block',x56='85px',x111='219px',x33='378px',x67='-2px',x44='-470px',e105='${Social_google_logo}',xc='rgba(0,0,0,1)',x60='-129px',x3='rgba(0,0,0,0)',x35='160px',x107='201px',d='display',x106='862px',x46='Store_invite',i='none',x109='rgba(192,192,192,1)',x72='139px',x29='241px',e104='${Block_social}',e103='${Social_text}',e102='${Social_facebook_login}',e101='${Social_facebook_logo}',x41='281px',x89='452px',e100='${Social_google_login}',x98='pointer',x61='86px',x84='80px',x97='44px',x96='192px',x38='147px',x54='-377px',x24='auto',x83='451px',x85='Social_google_login',e65='${Store_invite}',x68='Block_social',x14='rgba(255,255,255,1)',tp='top',x40='500px',x17='700px',x22='794px',x82='1000px',x94='42px',x34='494px',x88='900px',x1='5.0.0',x91='Social_facebook_login',x73='Social_google_logo',x108='Rectangle',x55='362px',g='image',x93='Social_text',x87='124px',x95='53px',x70='398px',x='text',x79='Social_facebook_logo',x18='658px',x52='Store_like',m='rect',x21='0px',x75='164px',x78='146px',x77='140px',x76='710px',x81='119px',x59='173px',x13='break-word',x39='365px',p='px',o='opacity',e15='${Click1}',x10='90',x71='717px',x26='Play_btn',x90='78px',x50='88px',x19='657px',x11='Arial, Helvetica, sans-serif',x31='Voice_wave',x27='273px',e64='${Store_movie}',x58='Store_movie',x110='htc_down',x47='170px',x48='-257px',x53='174px',x49='367px',x20='proto_guess_0018_Background4',x23='1554px',x28='904px';var g36='proto_guess_0016_Voice_wave.png',g42='sound_wave.gif',g74='proto_guess_0012_Social_google_logo.png',g99='proto_guess_0005_Social_text.png',g5='proto_guess_0013_Monye_bag.png',g62='proto_guess_0007_Store_movie.png',g92='proto_guess_0006_Social_facebook_login.png',g6='proto_guess_0002_htc_left.png',g86='proto_guess_0010_Social_google_login.png',g112='htc_down.jpg',g7='proto_guess_0001_htc_right.png',g69='proto_guess_0015_Block_social.png',g45='proto_guess_0014_Block_store.png',g80='proto_guess_0011_Social_facebook_logo.png',g25='proto_guess_0018_Background4.png',g57='proto_guess_0008_Store_like.png',g30='proto_guess_0017_Play_btn.png',g51='proto_guess_0009_Store_invite.png',g8='htc_up.jpg',g4='proto_guess_0004_Store_text.png';var s9="Click";var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[{id:'Background_sym',symbolName:'Background_sym',t:m,r:['0','0','794','1554','auto','auto']},{id:'Store',symbolName:'Store_symbol',t:m,r:['47px','157','700','658','auto','auto']},{id:'Social',symbolName:'Social',t:m,r:['47px','703px','700','657','auto','auto']},{id:'Store_text',t:g,r:['98px','174px','173px','44px','auto','auto'],cu:'pointer',f:[x3,im+g4,'0px','0px']},{id:'Monye_bag',t:g,r:['638px','170px','87px','90px','auto','auto'],f:[x3,im+g5,'0px','0px']},{id:'htc_down3',symbolName:'htc_down',t:m,r:['0','1340px','794','219','auto','auto'],tf:[[],[],[],['1','1.05372']]},{id:'htc_left',t:g,r:['0px','155px','55px','1183px','auto','auto'],f:[x3,im+g6,'0px','0px']},{id:'htc_right',t:g,r:['746px','152px','46px','1183px','auto','auto'],f:[x3,im+g7,'0px','0px']},{id:'htc_up',t:g,r:['0','-18px','793px','173px','auto','auto'],f:[x3,im+g8,'0px','0px']},{id:'Click1',v:b,t:x,r:['71px','147px','275px','137px','auto','auto'],overflow:'visible',o:1,text:s9,n:[x11,[x10,p],"rgba(240,4,4,1.00)",x12,i,"",x13,""]},{id:'Click2',v:b,t:x,r:['71px','1182px','275px','137px','auto','auto'],o:1,text:s9,n:[x11,[x10,p],"rgba(240,4,4,1.00)",x12,i,"",x13,""]}],style:{'${Stage}':{isStage:true,r:['null','null','794px','1554px','auto','auto'],overflow:'hidden',f:[x14]}}},tt:{d:6000,a:y,data:[["eid55",o,0,6000,"easeOutCubic",e15,'1','0'],["eid57",d,6000,0,"easeOutCubic",e16,b,i],["eid56",o,0,6000,"easeOutCubic",e16,'1','0'],["eid58",d,6000,0,"easeOutCubic",e15,b,i]]}},"Store_sym":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[],style:{'${symbolSelector}':{r:[_,_,x17,x18]}}},tt:{d:0,a:y,data:[]}},"Social_sym":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[],style:{'${symbolSelector}':{r:[_,_,x17,x19]}}},tt:{d:0,a:y,data:[]}},"Background_sym":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[{t:g,id:x20,r:[x21,x21,x22,x23,x24,x24],f:[x3,im+g25,x21,x21]},{t:g,id:x26,r:[x27,x28,x29,x29,x24,x24],f:[x3,im+g30,x21,x21]},{t:g,id:x31,r:[x32,x33,x34,x35,x24,x24],f:[x3,im+g36,x21,x21]},{t:g,id:x37,r:[x38,x39,x40,x41,x24,x24],f:[x3,im+g42,x21,x21]}],style:{'${symbolSelector}':{r:[_,_,x22,x23]}}},tt:{d:0,a:y,data:[]}},"Store_symbol":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[{t:g,id:x43,r:[x21,x44,x17,x18,x24,x24],f:[x3,im+g45,x21,x21]},{t:g,id:x46,r:[x47,x48,x49,x50,x24,x24],f:[x3,im+g51,x21,x21]},{t:g,id:x52,r:[x53,x54,x55,x56,x24,x24],f:[x3,im+g57,x21,x21]},{t:g,id:x58,r:[x59,x60,x55,x61,x24,x24],f:[x3,im+g62,x21,x21]}],style:{'${symbolSelector}':{r:[_,_,x17,x18]}}},tt:{d:500,a:y,data:[["eid24",tp,0,500,"easeOutCubic",e63,'-470px','0px'],["eid21",tp,0,500,"easeOutCubic",e64,'-129px','371px'],["eid23",tp,0,500,"easeOutCubic",e65,'-257px','243px'],["eid22",tp,0,500,"easeOutCubic",e66,'-377px','123px']]}},"Social":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[{r:[x21,x67,x17,x19,x24,x24],id:x68,t:g,f:[x3,im+g69,x21,x21]},{r:[x70,x71,x72,x72,x24,x24],id:x73,t:g,f:[x3,im+g74,x21,x21]},{r:[x75,x76,x77,x78,x24,x24],id:x79,t:g,f:[x3,im+g80,x21,x21]},{r:[x81,x82,x83,x84,x24,x24],id:x85,t:g,f:[x3,im+g86,x21,x21]},{r:[x87,x88,x89,x90,x24,x24],id:x91,t:g,f:[x3,im+g92,x21,x21]},{t:g,id:x93,r:[x94,x95,x96,x97,x24,x24],cu:x98,f:[x3,im+g99,x21,x21]}],style:{'${symbolSelector}':{r:[_,_,x17,x19]}}},tt:{d:500,a:y,data:[["eid35",tp,0,500,"easeOutCubic",e100,'1000px','490px'],["eid34",tp,0,500,"easeOutCubic",e101,'710px','200px'],["eid37",tp,0,500,"easeOutCubic",e102,'900px','390px'],["eid33",tp,0,500,"easeOutCubic",e103,'541px','53px'],["eid36",tp,0,500,"easeOutCubic",e104,'470px','-2px'],["eid38",tp,0,500,"easeOutCubic",e105,'717px','207px']]}},"Symbol_1":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[{r:[x21,x21,x106,x107,x24,x24],id:x108,s:[0,xc,i],t:m,f:[x109]}],style:{'${symbolSelector}':{r:[_,_,x106,x107]}}},tt:{d:0,a:y,data:[]}},"htc_down":{v:x1,mv:x1,b:x2,stf:i,cg:i,rI:n,cn:{dom:[{t:g,id:x110,r:[x21,x21,x22,x111,x24,x24],f:[x3,im+g112,x21,x21]}],style:{'${symbolSelector}':{r:[_,_,x22,x111]}}},tt:{d:0,a:y,data:[]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-21094723");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${Store_text}","click",function(sym,e){if(sym.getComposition().getStage().getSymbol('Store').upBool==0){sym.getComposition().getStage().getSymbol('Store').playReverse();sym.getComposition().getStage().getSymbol('Store').upBool=1;}
else{sym.getComposition().getStage().getSymbol('Store').play();sym.getComposition().getStage().getSymbol('Store').upBool=0;}});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'Store_sym'
(function(symbolName){})("Store_sym");
//Edge symbol end:'Store_sym'

//=========================================================

//Edge symbol: 'Social_sym'
(function(symbolName){})("Social_sym");
//Edge symbol end:'Social_sym'

//=========================================================

//Edge symbol: 'Background_sym'
(function(symbolName){})("Background_sym");
//Edge symbol end:'Background_sym'

//=========================================================

//Edge symbol: 'Store_symbol'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();upBool=0;});
//Edge binding end
})("Store_symbol");
//Edge symbol end:'Store_symbol'

//=========================================================

//Edge symbol: 'Social'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();var upBool=0;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Social_text}","click",function(sym,e){if(sym.getComposition().getStage().getSymbol('Social').upBool==0){sym.getComposition().getStage().getSymbol('Social').playReverse();sym.getComposition().getStage().getSymbol('Social').upBool=1;}
else{sym.getComposition().getStage().getSymbol('Social').play();sym.getComposition().getStage().getSymbol('Social').upBool=0;}});
//Edge binding end
})("Social");
//Edge symbol end:'Social'

//=========================================================

//Edge symbol: 'Symbol_1'
(function(symbolName){})("Symbol_1");
//Edge symbol end:'Symbol_1'

//=========================================================

//Edge symbol: 'htc_down'
(function(symbolName){})("htc_down");
//Edge symbol end:'htc_down'
})})(AdobeEdge.$,AdobeEdge,"EDGE-21094723");